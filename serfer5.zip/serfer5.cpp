#include <iostream>
#include <string>

using namespace std;

int main () {
	string abc="abcdefghijklmnopqrstuvwxyz " ;
	string text , mode , key ,  cmp=abc;
	int i, j , k=5  ;
	cout<<"ahlan ya user ya habibi"<<endl;
	cout<<"what do you want to do today ?"<<endl;
	cout<<"	1- cipher a message \n	2- decipher a message \n	3- End"<<endl;
	while ( true ) 
	{
		cin>>mode;
		if ( mode!="1" && mode!="2" && mode!="3" ) {
			cout<<"only choose 1 , 2 or 3 "<<endl;
			continue;
		}
		break;
	}
	
	if ( mode== "3" ) {
		cout<<"See you...";
		return 0;
	}
	
	cout<<"Enter the text :"<<endl;
	cin.get();
	getline(cin, text) ;
	for ( i=0 ; i<text.length() ; i++ ) {
		if ( text[i]>='A' && text[i]<='Z' ) {
			text[i]=text[i]+32;} }
	cout<<"Enter the key : ";
	while(true) {
		j=5;
		cin>>key;
		for ( i=0 ; i<5 && j==5 ; i++) {
			for ( j=0 ; j<5 ; j++) {
				if (i==j) {continue;}
				if (key[i] == key[j]) {break;}
			}
		} 
		if ( i!=5 && j!=5 || key.length()!=5 ) {
			cout<<"Invalid key, enter another key : ";
			continue;} 
		else {break;}
	} 
	for ( i=0 ; i<5 ; i++ ) {
		cmp[i]=key[i];
	} 
	for ( i=0 ; i<26 ; i++) {
		for ( j=0 ; j<5 ; j++ ) {
			if (abc[i] == cmp[j]) {
				break;
			} 
		}
		
		if (j==5) {
			cmp[k]=abc[i] ;
			k+=1;
		} 
	} 
	if (mode == "1" ) {
	for (i=0 ; i<text.length() ; i++) {
		for (j=0 ; j<27 ; j++) {
			if (text[i] == abc[j]) {
				cout<<cmp[j] ;
				break;
			} 
		}
	}
	} 
	
	else if ( mode == "2" ) 
	{
	for (i=0 ; i<text.length() ; i++)
		 {
		for (j=0 ; j<27 ; j++) 
		 	{
			if (text[i] == cmp[j]) 
		 		{
				cout<<abc[j] ;
				break;
			} 
		}
	}
	}
} 
