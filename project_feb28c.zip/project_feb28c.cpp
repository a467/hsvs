#include <iostream>
#include <string>
using namespace std ;
int main()
{
    string x ="abcdefghijklmnopqrstuvwxyz ";
    string y= "phqgiumeaylnofdxjkrcvstzwb ";
    string z;
    cout <<"enter your word \n";
    getline(cin,z);
    for (int  i=0;i<z.length();i++)
    {
        for (int  j=0; j<27; j++)
        {
            if (z[i]==x[j])
            {
                cout << y[j];
                break;
            }
        }
    }
    
    
    
 return 0;   
    
}
