#include <iostream>
#include <string>
using namespace std ;
int main()
{
    int rows ;
    cin >> rows;
    for (int i=1; i<=rows; i++)
    {
        for (int x=0;x<rows-i; x++)
        {
            cout <<" "; 
            }
            for(int x=0 ;x<i*2-1;x++)
        {
                cout <<"*";
        }
       
   
    cout << endl;
    
}
    
 return 0;   
    
}
