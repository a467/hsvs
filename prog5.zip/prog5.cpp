#include <iostream>
using namespace std;
int main ()
{
     //each grade is between 1 to 10
    //number of exercises is 3
    float n,y,x,f,z,g;
    float d;
    cout <<"enter grade of the firist exercise" <<endl;
    cin >> n;
    while (n<0 || n>10) {
    	cout<<"invalid grade"<<endl;
    	main();
    	return 0; }
    cout << "enter the grade of the second exercise"<<endl;
    cin>> y;
    while (y<0 || y>10) {
    	cout<<"invalid grade"<<endl;
    	main();
    	return 0; }
    cout <<"enter the grade of the third exercise " <<endl;
    cin >> x;
    while (x<0 || x>10) {
    	cout<<"invalid grade"<<endl;
    	main();
    	return 0; }
    //each exercise full markets is 10
    f=n+y+x;
    //g=full markets of three exercise =30
    g=30;
    z=f/g;
    d=z*100;
    cout << "yor total is "<<f<<endl;
    cout << "your tota grade in sentenge is "<<d<<"%"<<endl;
return 0;
    }
    
    
    
    
    
