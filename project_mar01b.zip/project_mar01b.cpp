#include <iostream>
using namespace std;
int main ()
{
  //each grade is between 1 to 10
	//number of exercises is 3
	int n,y,x,f,z,g;
	float d;
	cout <<"enter grade of the firist exercise" <<endl;
	cin >> n;
	cout << "enter the grade of the second exercise"<<endl;
	cin>> y;
	cout <<"enter the grade of the third exercise " <<endl;
	cin >> x;
	//each exercise full markets is 10
	f=n+y+x;
	//g=full markets of three exercise =30
	g=30;
	z=f%g;
	d=z*.01;
	cout << "yor total is "<<z <<endl;
	cout << "your tota grade in sentenge is "<<d<<endl;
return 0;
	}
	
	
	
	
	
